# BADAL FF PRO

Bilingual (Hindi/English) Free Fire practice companion. It includes sensitivity notes, a HUD layout guide, and a simple daily practice tracker. It does not modify Free Fire, access accounts, bypass bans, or provide cheats.

## Build the APK
1. Open this folder in Android Studio (recent version).
2. Allow Gradle sync; install Android SDK Platform 35 if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be in `app/build/outputs/apk/debug/`.

This environment did not have Android SDK/Gradle installed, so this package contains the complete Android Studio project source rather than a compiled APK.
